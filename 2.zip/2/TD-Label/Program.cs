﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection.Emit;
using Yang;
using Veneti;
using LET_A;

namespace TDNNSTP
{
    class Program
    {
        static void Main(string[] args)
        {
            string type = Console.ReadLine().ToString();
            Random ra = new Random();
            int deadLine;
            switch (type)
            {
                case "time-window":
                    Console.WriteLine("start time-window");
                    string filePath;
                    string filename;
                    int startNode;
                    int destNode;
                    int NeuronNumber;
                    DirectoryInfo dir;
                    StreamWriter writer = new StreamWriter(@"../../result/time-window-1230.csv");
                    
                    for (int i = 1; i <= 5; i++)
                    {
                        filePath = @"../../DS/tw/4941/250-" + i + "-netsci-4941-.csv";
                        dir = new DirectoryInfo(filePath);
                        filename = dir.FullName;
                        for (int u = 1; u <= 20; u++)
                        {

                            startNode = ra.Next(0, 2940);
                            destNode = ra.Next(2000, 4940);
                            NeuronNumber = 4941;
                            deadLine = 250;
                            AWT(filename, startNode, destNode, NeuronNumber, deadLine, writer);
                        }
                    }

                    Console.WriteLine("end time-window");
                    writer.Close();
                    //goto case "number";
                    break;
                case "number":
                    Console.WriteLine("start number");
                    writer = new StreamWriter(@"../../result/number-1218.csv");
                    for (int j = 50; j <= 200; j += 50)
                    {
                        for (int u = 1; u <= 10; u++)
                        {
                            filePath = @"../../DS/nm/" + j + "/05-50-graph-" + j + "-" + u + ".csv";
                            dir = new DirectoryInfo(filePath);
                            filename = dir.FullName;
                            for (int v = 1; v <= 20; v++)
                            {
                                startNode = ra.Next(0, j);
                                destNode = ra.Next(0, j);
                                NeuronNumber = j;
                                deadLine = 50;
                                AWT(filename, startNode, destNode, NeuronNumber, deadLine, writer);
                            }
                        }

                    }
                    writer.Close();
                    Console.WriteLine("end");
                    goto case "delay";
                case "delay":
                    Console.WriteLine("start delay");
                    writer = new StreamWriter(@"../../result/delay-1222.csv");

                    for (int i = 200; i <= 250; i += 10)
                    {
                        filePath = @"../../DS/dl/4941/" + i + "-5-netsci-4941-.csv";
                        dir = new DirectoryInfo(filePath);
                        filename = dir.FullName;
                        deadLine = i;
                        for (int v = 1; v <= 10; v++)
                        {
                            startNode = ra.Next(0, 2940);
                            destNode = ra.Next(2940, 4940);
                            NeuronNumber = 4941;
                            AWT(filename, startNode, destNode, NeuronNumber, deadLine, writer);
                        }
                    }

                    for (int i = 50; i <= 100; i += 10)
                    {
                        filePath = @"../../DS/dl/22962/" + i + "-5-netsci-22962-.csv";
                        dir = new DirectoryInfo(filePath);
                        filename = dir.FullName;
                        deadLine = i;
                        for (int v = 1; v <= 10; v++)
                        {
                            startNode = ra.Next(0, 22961);
                            destNode = ra.Next(0, 22961);
                            NeuronNumber = 22962;
                            AWT(filename, startNode, destNode, NeuronNumber, deadLine, writer);
                        }
                    }
                    Console.WriteLine("end");
                    writer.Close();
                    break;
            }
        }
        private static void AWT(string filename, int startNode, int destNode, int NeuronNumber, int deadLine, StreamWriter writer)
        {
            char[] Label = { 'a', 'c', 'e' };
            string strFileName = filename.Substring(filename.LastIndexOf("\\") + 1, filename.Length - 1 - filename.LastIndexOf("\\"));

            Console.WriteLine(strFileName);
            Console.WriteLine();
            Console.WriteLine("Yang start");
            Yang.Yang djk = new Yang.Yang(filename, NeuronNumber, deadLine, Label);
            Stopwatch djkWatch = new Stopwatch();
            djkWatch.Start();
            djk.ShortestPath(startNode, destNode);
            djkWatch.Stop();
            double djkRuntime = djkWatch.ElapsedTicks * 1000000F / Stopwatch.Frequency;
            Console.WriteLine($"yang result: {djk.DestNodeArrTime}");
            Console.WriteLine($"WDNN time: {djkRuntime:n0}us");
            Console.WriteLine();

            Console.WriteLine("WDNN start");
            TDCSP.WDNN tdcsp = new TDCSP.WDNN(filename, NeuronNumber, deadLine, Label);
            Stopwatch tdcspWatch = new Stopwatch();
            tdcsp.NIA(startNode, destNode);
            tdcspWatch.Start();
            tdcsp.TL_main();
            tdcspWatch.Stop();
            double TdcspRuntime = tdcspWatch.ElapsedTicks * 1000000F / Stopwatch.Frequency;
            Console.WriteLine($"WDNN result:  {tdcsp.DestNodeArrivalTime}");
            Console.WriteLine($"WDNN time: {TdcspRuntime:n0}us");
            Console.WriteLine();


            Console.WriteLine("Veneti start");
            Veneti.Veneti fls = new Veneti.Veneti(filename, NeuronNumber, deadLine, Label);
            Stopwatch flsWatch = new Stopwatch();
            flsWatch.Start();
            fls.DTLFS(startNode, destNode);
            flsWatch.Stop();
            double flsRuntime = flsWatch.ElapsedTicks * 1000000F / Stopwatch.Frequency;
            Console.WriteLine($"Veneti result: {fls.DestNodeArrTime}");
            Console.WriteLine($"Veneti time: {flsRuntime:n0}us");
            Console.WriteLine();

            Console.WriteLine("LET_A start");
            LET_A.LET_A let = new LET_A.LET_A(filename, NeuronNumber, deadLine, Label.ToList());
            Stopwatch letWatch = new Stopwatch();
            letWatch.Start();
            let.LET_A_MAIN(startNode, destNode);
            letWatch.Stop();
            double letRuntime = letWatch.ElapsedTicks * 1000000F / Stopwatch.Frequency;
            Console.WriteLine($"LET result: {let.ArrTimeDestination}");
            Console.WriteLine($"LET time: {letRuntime:n0}us");
            Console.WriteLine();

            writer.WriteLine(strFileName + ",WDNN," + tdcsp.DestNodeArrivalTime + "," + TdcspRuntime + ",Veneti," + fls.DestNodeArrTime + "," + flsRuntime + ",Yang," + djk.DestNodeArrTime + "," + djkRuntime + ",LET_A," + let.ArrTimeDestination + "," + letRuntime);
            writer.Flush();
        }

    }
}
